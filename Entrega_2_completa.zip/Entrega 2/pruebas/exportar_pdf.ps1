param([string]$Documento, [string]$PDF)
$ErrorActionPreference = 'Stop'
$Documento = (Get-Item -LiteralPath $Documento).FullName
$PDF = [System.IO.Path]::GetFullPath($PDF).Replace('/', '\')
$word = New-Object -ComObject Word.Application
$word.Visible = $false
$word.DisplayAlerts = 0
$documentoAbierto = $null
try {
    $documentoAbierto = $word.Documents.Open($Documento, $false, $true)
    $documentoAbierto.Fields.Update() | Out-Null
    $documentoAbierto.ExportAsFixedFormat($PDF, 17)
    Write-Output ('PDF exportado. Paginas: ' + $documentoAbierto.ComputeStatistics(2))
} finally {
    if ($null -ne $documentoAbierto) { $documentoAbierto.Close(0) }
    $word.Quit()
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($word) | Out-Null
}
