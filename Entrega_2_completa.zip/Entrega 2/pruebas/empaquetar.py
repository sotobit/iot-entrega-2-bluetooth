"""Crea un ZIP con la entrega completa y prepara archivos para GitHub."""
import hashlib
import json
import re
import shutil
import sys
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from pypdf import PdfReader

BASE=Path(__file__).resolve().parent.parent
DEST=BASE.parent/'Entrega_2_Arduino.zip'
PUBLICAR=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else None
pdf=PdfReader(BASE/'informe/Entrega 2 IEEE.pdf')
assert len(pdf.pages)==4
body='\n'.join(page.extract_text() or '' for page in pdf.pages)
normalized=re.sub(r'\s+','',body).casefold()
assert all(re.sub(r'\s+','',x).casefold() in normalized for x in ['Abstract','Index Terms','Referencias','9600','50'])
assert 'Pendiente' not in body
uris=[]
for page in pdf.pages:
    for ref in page.get('/Annots',[]):
        action=ref.get_object().get('/A',{})
        if action.get('/URI'):uris.append(str(action['/URI']))
urls=json.loads((BASE/'ENLACES.json').read_text(encoding='utf-8'))
assert all(url in uris for url in urls.values())
assert len(PdfReader(BASE/'informe/Anexo de las 50 pruebas.pdf').pages)==2
assert len(list((BASE/'resultados/capturas').glob('*.png')))>=54
manifest=BASE/'SHA256SUMS.txt'
files=sorted(p for p in BASE.rglob('*') if p.is_file() and p!=manifest and '__pycache__' not in p.parts)
manifest.write_text('\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(BASE).as_posix() for p in files)+'\n',encoding='utf-8')
files.append(manifest)
with ZipFile(DEST,'w',ZIP_DEFLATED,compresslevel=9) as archive:
    for p in files:archive.write(p,Path('Entrega 2')/p.relative_to(BASE))
with ZipFile(DEST) as archive:
    assert archive.testzip() is None
    assert len([p for p in archive.namelist() if '/resultados/capturas/' in p and p.endswith('.png')])>=54
if PUBLICAR:
    PUBLICAR.mkdir(parents=True,exist_ok=True)
    sources={
        BASE/'codigo/ControlBluetooth/ControlBluetooth.ino':'ControlBluetooth.ino',
        BASE/'simulacion/Entrega2.mokxi.json':'diagram.mokxi.json',
        BASE/'informe/Entrega 2 IEEE.pdf':'Entrega_2_IEEE.pdf',
        BASE/'informe/Entrega 2 IEEE.docx':'Entrega_2_IEEE.docx',
        BASE/'informe/Anexo de las 50 pruebas.pdf':'Anexo_50_pruebas.pdf',
        BASE/'resultados/pruebas_50.csv':'pruebas_50.csv',
        BASE/'resultados/monitor_serial_50_original.txt':'monitor_serial_50_original.txt',
        BASE/'resultados/graficas/01_resultados_comandos.png':'resultados_comandos.png',
        BASE/'resultados/graficas/02_estados_50_pruebas.png':'estados_50_pruebas.png',
        BASE/'resultados/graficas/03_circuito_recorte.png':'circuito.png',
        BASE/'FUENTES.md':'FUENTES.md',
        BASE/'BASE_ACADEMICA.md':'BASE_ACADEMICA.md',
        manifest:'SHA256SUMS.txt',DEST:'Entrega_2_completa.zip'}
    for src,name in sources.items():shutil.copyfile(src,PUBLICAR/name)
    readme=(BASE/'README.md').read_text(encoding='utf-8')
    downloads='## Descargas directas\n\n'
    for label,file in [('Artículo PDF','Entrega_2_IEEE.pdf'),('Artículo Word','Entrega_2_IEEE.docx'),('Tabla completa de 50 pruebas','Anexo_50_pruebas.pdf'),('Proyecto completo con capturas y scripts','Entrega_2_completa.zip')]:
        downloads+='- ['+label+']('+file+')\n'
    readme=readme.replace('## Abrir el proyecto',downloads+'\n## Abrir el proyecto',1)
    (PUBLICAR/'README.md').write_text(readme,encoding='utf-8')
print('ZIP verificado:',len(files),'archivos;',round(DEST.stat().st_size/1024/1024,2),'MiB.')
print('PDF: 4 paginas; anexo: 2 paginas; enlaces PDF activos:',len(uris))
