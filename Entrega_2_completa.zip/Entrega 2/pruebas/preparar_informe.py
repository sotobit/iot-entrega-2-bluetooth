"""Verifica registros originales, crea graficas y prepara el articulo IEEE."""
import csv
import hashlib
import json
import re
from pathlib import Path
from zipfile import ZipFile
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
from docx import Document
from docx.enum.section import WD_SECTION_START
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Mm, Pt, RGBColor
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4

BASE=Path(__file__).resolve().parent.parent
R=BASE/'resultados'; G=R/'graficas'; I=BASE/'informe'
G.mkdir(exist_ok=True); I.mkdir(exist_ok=True)
rows=json.loads((R/'pruebas_50.json').read_text(encoding='utf-8'))
serial=(R/'monitor_serial_50_original.txt').read_text(encoding='utf-8')
expected={'B':(1,0,'OK'),'R':(0,1,'OK'),'A':(1,1,'OK'),'X':(1,1,'INVALIDO'),'0':(0,0,'OK')}
assert len(rows)==50
for i,r in enumerate(rows,1):
    assert r['id']==i and (r['verde'],r['rojo'],r['resultado'])==expected[r['comando']]
    assert ','.join(str(r[f]) for f in ['id','tiempo_ms','comando','verde','rojo','resultado']) in serial
    assert (R/r['captura']).is_file()
    if i>1: assert r['tiempo_ms']>rows[i-2]['tiempo_ms']
assert all(sum(r['comando']==c for r in rows)==10 for c in expected)
original=json.loads((BASE/'simulacion/Entrega2.mokxi.json').read_text(encoding='utf-8'))
export=json.loads((BASE/'simulacion/Exportacion_editor.mokxi.json').read_text(encoding='utf-8'))
ino=(BASE/'codigo/ControlBluetooth/ControlBluetooth.ino').read_text(encoding='utf-8')
assert original['projects']['uno1']['files']['sketch.ino']==ino
assert export['projects']['uno1']['files']['sketch.ino']==ino
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':230})
fig,ax=plt.subplots(figsize=(5.4,3.1),layout='constrained')
labels=['B\nVerde','R\nRojo','A\nAmbos','0\nApagado','X\nRechazo']
bars=ax.bar(labels,[10]*5,color=['#33864a','#b84044','#9f7435','#576a7b','#4c70a6'])
ax.bar_label(bars,labels=['10/10']*5,padding=3)
ax.set(ylabel='Pruebas que cumplieron lo esperado',ylim=(0,12),yticks=range(0,11,2))
ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
fig.savefig(G/'01_resultados_comandos.png');fig.savefig(G/'01_resultados_comandos.svg');plt.close(fig)
fig,axes=plt.subplots(2,1,figsize=(5.4,3.2),sharex=True,layout='constrained')
for ax,key,label,color in zip(axes,['verde','rojo'],['LED verde','LED rojo'],['#33864a','#b84044']):
    ax.step([r['id'] for r in rows],[r[key] for r in rows],where='post',color=color)
    ax.scatter([r['id'] for r in rows if r['comando']=='X'],[r[key] for r in rows if r['comando']=='X'],marker='x',color='black',s=20,label='X invalido')
    ax.set(ylabel=label,yticks=[0,1],yticklabels=['Apagado','Encendido'],ylim=(-.2,1.25));ax.grid(alpha=.15)
axes[0].legend(fontsize=10,loc='lower right');axes[1].set(xlabel='Numero de prueba',xticks=[1,10,20,30,40,50])
fig.savefig(G/'02_estados_50_pruebas.png');fig.savefig(G/'02_estados_50_pruebas.svg');plt.close(fig)
# Son recortes identificados de capturas autenticas; no se redibuja el circuito.
Image.open(R/'capturas/03_A_repeticion_1.png').crop((258,175,1058,710)).save(G/'03_circuito_recorte.png')
Image.open(R/'capturas/52_terminal_bluetooth.png').crop((490,895,790,1155)).save(G/'04_terminal_recorte.png')

# Anexo legible con TODOS los datos, ademas de CSV/JSON y monitor sin filtrar.
styles=getSampleStyleSheet()
story=[Paragraph('Anexo de las 50 pruebas de control Bluetooth',styles['Title']),
 Paragraph('Johan Sebastian Soto Ramirez · Internet de las Cosas · 21 de noviembre de 2026',styles['Normal']),Spacer(1,8),
 Paragraph('Registros obtenidos en Mokxi. Tiempo_ms corresponde al reloj del Arduino simulado. '
           '1 = LED encendido; 0 = apagado. X se envia despues de A y debe mantener ambos LED encendidos. '
           'El rechazo INVALIDO es el resultado esperado de X. Cada captura esta identificada en pruebas_50.csv.',styles['Normal']),Spacer(1,10)]
data=[['ID','Tiempo ms','Comando','Verde','Rojo','Respuesta','Verificacion']]
for r in rows: data.append([str(r[k]) for k in ['id','tiempo_ms','comando','verde','rojo','resultado','verificacion']])
t=Table(data,repeatRows=1,colWidths=[29,67,65,47,47,75,81])
t.setStyle(TableStyle([('FONTNAME',(0,0),(-1,-1),'Helvetica'),('FONTSIZE',(0,0),(-1,-1),8),('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e3eaf0')),('LINEBELOW',(0,0),(-1,0),.6,colors.black),('LINEBELOW',(0,1),(-1,-1),.15,colors.HexColor('#bbbbbb')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f4f6f8')]),('TOPPADDING',(0,0),(-1,-1),4),('BOTTOMPADDING',(0,0),(-1,-1),4)]))
story.append(t)
SimpleDocTemplate(str(I/'Anexo de las 50 pruebas.pdf'),pagesize=A4,rightMargin=35,leftMargin=35,topMargin=35,bottomMargin=35).build(story)

TEMPLATE=BASE/'pruebas/Plantilla_IEEE_referencia.docx'
doc=Document(TEMPLATE)
for e in list(doc._element.body):
    if e.tag!=qn('w:sectPr'):doc._element.body.remove(e)
for s in doc.styles:
    if s.type==1:
        s.font.name='Times New Roman';s.font.color.rgb=RGBColor(0,0,0)
        if s._element.pPr is not None:
            for tag in ['framePr','numPr','pBdr']:
                for e in list(s._element.pPr.findall(qn('w:'+tag))):s._element.pPr.remove(e)
n=doc.styles['Normal'];n.font.size=Pt(10)
n.paragraph_format.space_after=Pt(3);n.paragraph_format.line_spacing=1
n.paragraph_format.first_line_indent=Mm(3.5);n.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY
n.paragraph_format.widow_control=True
for name,size in [('Title',24),('Authors',11),('Abstract',9),('Heading 1',9),('Heading 2',10)]:
    doc.styles[name].font.size=Pt(size);doc.styles[name].paragraph_format.first_line_indent=Mm(0)
doc.styles['Title'].paragraph_format.alignment=WD_ALIGN_PARAGRAPH.CENTER
doc.styles['Heading 1'].paragraph_format.alignment=WD_ALIGN_PARAGRAPH.CENTER
doc.styles['Heading 1'].paragraph_format.space_before=Pt(9)
doc.styles['Heading 1'].paragraph_format.space_after=Pt(5)
doc.styles['Heading 1'].font.bold=False;doc.styles['Heading 1'].font.small_caps=True
doc.styles['Heading 2'].font.bold=False;doc.styles['Heading 2'].font.italic=True
for name in ['Heading 1','Heading 2']:doc.styles[name].paragraph_format.keep_with_next=True
doc.sections[0]._sectPr.find(qn('w:cols')).set(qn('w:num'),'1')
doc.add_paragraph('Control de dos luces LED mediante Arduino y Bluetooth en simulación','Title')
for text in ['Johan Sebastian Soto Ramirez','Ingeniería de Software · Politécnico Grancolombiano','jsesoto@poligran.edu.co','Internet de las Cosas · Entrega 2','Profesor Jesús Antonio Figueroa Guerrero']:
    p=doc.add_paragraph(text,'Authors');p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after=Pt(2);p.paragraph_format.keep_with_next=True
    for run in p.runs:run.font.size=Pt(10)
s=doc.add_section(WD_SECTION_START.CONTINUOUS);cols=s._sectPr.find(qn('w:cols'));cols.set(qn('w:num'),'2');cols.set(qn('w:space'),'240')
for s in doc.sections:
    s.page_width=Mm(210);s.page_height=Mm(297);s.left_margin=Mm(13);s.right_margin=Mm(13);s.top_margin=Mm(19);s.bottom_margin=Mm(30)
def p(text,style=None):return doc.add_paragraph(text,style)
def h(text):return p(text,'Heading 1')
def sh(text):return p(text,'Heading 2')
def cap(text,keep=False):
    a=p(text);a.alignment=WD_ALIGN_PARAGRAPH.CENTER;a.paragraph_format.first_line_indent=Mm(0);a.paragraph_format.keep_with_next=keep
    for run in a.runs:run.font.size=Pt(8)
def table(headers,values,widths):
    t=doc.add_table(rows=1,cols=len(headers));t.autofit=False
    for c,w,text in zip(t.rows[0].cells,widths,headers):c.width=Mm(w);c.text=str(text)
    t.rows[0]._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
    for row in values:
        for c,w,text in zip(t.add_row().cells,widths,row):c.width=Mm(w);c.text=str(text)
    for col,w in zip(t.columns,widths):col.width=Mm(w)
    for i,row in enumerate(t.rows):
        row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
        for cell in row.cells:
            for a in cell.paragraphs:
                a.paragraph_format.first_line_indent=Mm(0);a.paragraph_format.space_after=Pt(1);a.paragraph_format.keep_with_next=i<len(t.rows)-1
                a.alignment=WD_ALIGN_PARAGRAPH.LEFT
                for run in a.runs:run.font.size=Pt(8);run.bold=i==0
    borders=OxmlElement('w:tblBorders')
    for side in ['top','bottom','insideH']:
        e=OxmlElement('w:'+side);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'777777');borders.append(e)
    t._tbl.tblPr.append(borders)
def fig(name,text):
    a=p('');a.paragraph_format.first_line_indent=Mm(0);a.paragraph_format.keep_with_next=True;a.alignment=WD_ALIGN_PARAGRAPH.CENTER
    a.add_run().add_picture(str(G/name),width=Mm(87));cap(text)

p('Resumen. Se diseñó y simuló un circuito con Arduino Uno, un módulo HC-05 y dos luces LED para recibir órdenes de encendido y apagado. Se configuró una comunicación UART a 9600 baudios y se programaron cuatro comandos de control y el rechazo de entradas incorrectas. La implementación se evaluó en Mokxi mediante 50 pruebas, con diez repeticiones por comando y una captura por prueba. Los 40 comandos válidos produjeron los estados esperados y las diez entradas inválidas conservaron las salidas. También se comprobó el alias V para el LED verde. Se adjuntan el código comentado, el proyecto portable, los registros completos y las gráficas. Los resultados verifican el control lógico y la comunicación serial modelada; no constituyen mediciones de una conexión inalámbrica física.','Abstract')
p('Palabras clave. Arduino Uno, Bluetooth, HC-05, UART, simulación, control de LED.','Abstract')
p('Abstract. An Arduino Uno circuit with an HC-05 module and two LEDs was designed and simulated to receive switching commands. UART communication was configured at 9600 baud. The program implements four control commands and rejects invalid input. Fifty tests were performed in Mokxi, with ten repetitions per command and a screenshot for each test. All forty valid commands produced the expected output states, while ten invalid inputs preserved both outputs. An additional test confirmed the V alias for the green LED. The commented source code, portable project, complete serial records, and plots are provided. These results verify logical control and the modeled serial interface; they do not measure a physical wireless connection.','Abstract')
p('Index Terms. Arduino Uno, Bluetooth, HC-05, UART, simulation, LED control.','Abstract')
h('I. Introducción y objetivos')
p('La segunda entrega de Internet de las Cosas propone diseñar, configurar y simular un circuito que reciba comandos por Bluetooth [1]. Las orientaciones de clase precisan el uso de dos LED, la interpretación de comandos, las evidencias del funcionamiento y la presentación de los resultados en un artículo IEEE [2]. La práctica permite observar cómo una orden externa se convierte en una acción sobre una salida digital.')
p('El objetivo general fue implementar y verificar el control de un LED verde y uno rojo mediante un Arduino Uno y un HC-05 simulado. Los objetivos específicos fueron identificar la función de Bluetooth y UART, conectar correctamente RX y TX, programar comandos y respuestas, y comprobar los estados de salida mediante pruebas repetidas con evidencia propia.')
p('El alcance corresponde al circuito Bluetooth de la Entrega 2. La evaluación se realizó en un entorno virtual gratuito, sin comprar componentes ni contratar funciones de pago. La comunicación inalámbrica física queda fuera de lo medido.')
h('II. Fundamentos y antecedentes')
sh('A. Arduino y comunicación serial')
p('Arduino Uno Rev3 utiliza el microcontrolador ATmega328P. Sus pines digitales pueden funcionar como salidas para controlar LED [3]. El programa se organiza en setup(), que prepara el circuito una vez, y loop(), que revisa continuamente si llegan datos. Una variable de tipo char permite guardar el carácter recibido antes de decidir qué salidas activar.')
p('UART transmite datos mediante señales de transmisión TX y recepción RX. No necesita un reloj compartido: ambos extremos deben usar los mismos parámetros. En este proyecto se eligieron 9600 baudios, ocho bits de datos, sin paridad y un bit de parada, expresados como 8N1. TX de un dispositivo se conecta a RX del otro y se comparte GND. La biblioteca SoftwareSerial permite reservar D2 y D3 para el módulo y dejar libre el puerto USB para registrar las pruebas [6].')
sh('B. Bluetooth y módulo HC-05')
p('Bluetooth surgió a finales de la década de 1990 como una alternativa para comunicar dispositivos cercanos. Bluetooth Low Energy se incorporó en la versión 4.0 en 2010 y abrió posibilidades para sensores de bajo consumo. La revisión de Koulouras, Katsoulis y Zantalis [7] explica esta evolución y examina aplicaciones de BLE en IoT, así como dificultades de seguridad, energía e interferencia. En consecuencia, conviene distinguir Bluetooth Classic de BLE al seleccionar los componentes de una práctica.')
p('El HC-05 corresponde a Bluetooth Classic y ofrece comunicación serial transparente mediante SPP [5]. El perfil SPP define conexiones que emulan un cable serial usando RFCOMM entre dispositivos [4]. En un montaje real, el teléfono establece el enlace Bluetooth con el módulo y el Arduino recibe los bytes por UART. El HC-05 no agrega por sí solo conexión a Internet. Puede formar parte del enlace local de un sistema IoT que utilice otro dispositivo como pasarela.')
cap('TABLA I. VENTAJAS Y LÍMITES PARA ESTA PRÁCTICA',True)
table(['Aspecto','Aporte y limitación'],[
 ('Control local','Permite enviar órdenes sin un cable entre teléfono y módulo; depende de compatibilidad y alcance del enlace real.'),
 ('UART','Interfaz sencilla para Arduino; requiere RX/TX cruzados, GND común y la misma velocidad.'),
 ('HC-05','Adecuado para comandos SPP; no es un módulo BLE ni una conexión directa a Internet.'),
 ('Simulación','Facilita repetir y guardar pruebas; no demuestra alcance, interferencia, consumo ni seguridad de radio.')],[22,65])
sh('C. Trabajos relacionados y elección del simulador')
p('Basha y colaboradores [8] presentan una aplicación de automatización que integra Arduino Nano, HC-05 y un teléfono Android para controlar dispositivos mediante texto o voz. La relación con esta práctica está en la secuencia teléfono, módulo, microcontrolador y actuador. Aquí se mantiene una versión básica con dos LED y comandos de un carácter; no se implementaron reconocimiento de voz, sensores ambientales ni control de cargas domésticas.')
p('En educación, Abburi, Praveena y Priyakanth [9] estudian el uso de Tinkercad en laboratorios virtuales y reportan una encuesta a alrededor de 300 estudiantes. Ese trabajo respalda el valor formativo de la simulación, sin demostrar que cualquier simulador reproduzca todos los fenómenos físicos. Por ello, la elección de la herramienta debe depender del componente que se necesita observar.')
p('Se eligió Mokxi porque dispone de Arduino Uno, HC-05, compilación de código y una terminal Bluetooth modelada. Su documentación explica que los bytes del teléfono virtual salen por TXD del módulo y que las respuestas del Arduino entran por RXD [10]. Esto permite comprobar la ruta serial completa del montaje. La selección se apoya en esa capacidad documentada y en la ejecución realizada; no se afirma que exista una validación científica independiente del simulador.')
h('III. Metodología y diseño del circuito')
p('El trabajo se desarrolló en cuatro pasos: revisión de la guía y la transcripción, construcción del circuito, programación de los comandos y ejecución de una serie repetida de pruebas. Se conservaron el archivo del simulador y la exportación obtenida desde el editor para que el circuito y el programa puedan abrirse nuevamente.')
cap('TABLA II. COMPONENTES UTILIZADOS',True)
table(['Cantidad','Componente y función'],[('1','Arduino Uno R3: interpreta órdenes y controla salidas.'),('1','HC-05: puente serial Bluetooth modelado.'),('2','LED verde y rojo: salidas del circuito.'),('2','Resistencias de 220 Ω: limitan la corriente de los LED.'),('1 + 1','Resistencias de 1 kΩ y 2 kΩ: divisor hacia RXD.'),('1','Protoboard y conexiones de alimentación y señal.')],[16,71])
cap('TABLA III. CONEXIONES DEL MONTAJE',True)
table(['Origen','Destino'],[('D8','220 Ω → ánodo LED verde; cátodo a GND.'),('D9','220 Ω → ánodo LED rojo; cátodo a GND.'),('TXD del HC-05','D2, entrada RX de SoftwareSerial.'),('D3, TX Arduino','1 kΩ → nodo → RXD del HC-05.'),('Nodo RXD','2 kΩ → GND.'),('5 V y GND','VCC y GND del adaptador HC-05; tierra común.')],[27,60])
p('El divisor reduce nominalmente una salida de 5 V a 5 × 2/(1 + 2) = 3,33 V. Este valor es un cálculo de diseño, no una medición experimental. Se incluye porque la ficha del HC-05 especifica entradas y salidas de baja tensión [5]. La alimentación a 5 V corresponde a una placa adaptadora con regulador; en un montaje físico debe verificarse la variante y su tensión de alimentación antes de conectar el módulo.')
p('El montaje completo se muestra en la Fig. 1.')
fig('03_circuito_recorte.png','Fig. 1. Circuito ejecutado con ambos LED encendidos. Recorte de la captura original de la prueba 3.')
p('El puerto USB y la comunicación con el módulo se inicializaron a 9600 baudios. En el modelo utilizado, el HC-05 aparece conectado y su terminal indica esa velocidad. No se usó el modo AT durante las pruebas. En un módulo físico se debe comprobar o configurar la velocidad del modo datos; no se supone que todas las variantes tengan el mismo valor de fábrica [5].')
h('IV. Implementación del programa')
p('El archivo ControlBluetooth.ino configura D8 y D9 como salidas, apaga ambos LED al inicio y crea SoftwareSerial(2, 3). En cada recorrido de loop() consulta bluetooth.available(); cuando hay un byte, lo lee y lo entrega a procesarComando(). La selección se realiza con switch para que cada orden tenga un efecto definido y fácil de revisar.')
cap('TABLA IV. COMANDOS Y RESPUESTAS ESPERADAS',True)
table(['Comando','Verde','Rojo','Respuesta'],[('B o V','1','0','OK'),('R','0','1','OK'),('A','1','1','OK'),('0','0','0','OK'),('X u otro','Conserva','Conserva','INVALIDO')],[21,19,19,28])
p('Se conserva B para encender el verde porque esa letra aparece en la transcripción de clase. V funciona como alias por su relación con la palabra verde. Las órdenes distinguen mayúsculas de minúsculas y se envían individualmente. Los espacios y los finales de línea CR/LF se ignoran. Un carácter desconocido genera INVALIDO y no modifica las salidas.')
p('Después de procesar una orden, el monitor USB registra identificador, millis(), comando, estado verde, estado rojo y resultado. El HC-05 recibe además una confirmación como B:OK o X:INVALIDO. El campo millis() muestra el tiempo transcurrido dentro del Arduino simulado; no mide latencia de Bluetooth. SoftwareSerial no recibe mientras transmite, por lo que el protocolo de la prueba consiste en enviar una orden y esperar su respuesta antes de enviar la siguiente [6].')
h('V. Pruebas y resultados')
sh('A. Procedimiento de verificación')
p('Las pruebas se ejecutaron el 21 de noviembre de 2026 en Chrome mediante la interfaz web de Mokxi. Un script de Playwright abrió el proyecto, ejecutó la compilación, escribió en el panel Bluetooth y leyó las líneas que aparecieron en el monitor serial. También guardó una captura completa para cada orden. Las imágenes son capturas del navegador durante la ejecución; las figuras del artículo que usan recortes se identifican como tales.')
p('Se realizaron diez ciclos de B, R, A, X y 0, para un total de 50 pruebas. Esta cantidad supera las cinco repeticiones por comando solicitadas en clase [2]. La entrada X se envió después de A, cuando ambos LED estaban encendidos. Así se verificó que el rechazo conservara un estado activo, en lugar de comprobarlo únicamente con las luces apagadas.')
cap('TABLA V. RESULTADO DE LAS 50 PRUEBAS',True)
table(['Orden','Ensayos','Resultado esperado','Cumplen'],[('B','10','Verde 1, rojo 0','10'),('R','10','Verde 0, rojo 1','10'),('A','10','Verde 1, rojo 1','10'),('X','10','Mantiene 1 y 1; INVALIDO','10'),('0','10','Verde 0, rojo 0','10'),('Total','50','Estados y respuesta','50')],[12,15,42,18])
sh('B. Evidencias y datos completos')
p('Los 40 comandos válidos produjeron la salida esperada y los diez comandos X fueron rechazados sin cambiar los LED. El cumplimiento observado fue 50/50 dentro de esta serie de simulación. La prueba adicional 51 verificó V y obtuvo verde encendido, rojo apagado y respuesta OK. Esta comprobación adicional se conserva aparte y no se suma al total de 50.')
p('La Fig. 2 resume el cumplimiento por comando y la Fig. 3 muestra los estados de los LED durante la serie completa.')
fig('01_resultados_comandos.png','Fig. 2. Ensayos que cumplieron por comando. El rechazo de X es el comportamiento esperado.')
fig('02_estados_50_pruebas.png','Fig. 3. Estados registrados en las 50 pruebas. Las cruces marcan X; ambos LED conservan el valor 1.')
p('Se adjuntan pruebas_50.csv y pruebas_50.json con todos los registros, monitor_serial_50_original.txt con la lectura de pantalla sin filtrar y el anexo PDF con la tabla completa. Cada fila del CSV identifica su captura y la fecha UTC de obtención. Las 50 capturas originales permiten contrastar las respuestas con el circuito visible. Las gráficas se calcularon a partir de estos archivos, sin generar muestras adicionales.')
p('La Fig. 4 permite observar órdenes y confirmaciones en la terminal Bluetooth.')
fig('04_terminal_recorte.png','Fig. 4. Terminal Bluetooth con órdenes enviadas y confirmaciones recibidas. Recorte de la captura 52.')
h('VI. Discusión y limitaciones')
p('La secuencia de órdenes muestra que Arduino interpreta datos recibidos y actualiza sus salidas de forma coherente. La respuesta INVALIDO permite reconocer una entrada no admitida y mantener las luces en su estado anterior. El uso separado de UART por SoftwareSerial y del monitor USB facilita seguir lo que ocurre sin enviar las órdenes directamente al parser desde el monitor de Arduino.')
p('El resultado depende del alcance del modelo. Mokxi sustituye el teléfono por un panel y no transmite radiofrecuencia; tampoco reproduce alcance, interferencia, cifrado ni una conexión con un teléfono real [10]. Por tanto, las 50 coincidencias no permiten concluir una confiabilidad del 100 % para hardware físico. Tampoco se midieron potencia, consumo de energía o tiempo de respuesta inalámbrico.')
p('Las órdenes se probaron de forma secuencial y con la velocidad correcta. Quedan fuera de esta serie los errores de baudios, las ráfagas de varios comandos, la pérdida de alimentación y las desconexiones. Para una siguiente práctica física sería necesario comprobar esos casos, verificar la alimentación del adaptador y repetir las pruebas con una aplicación compatible con SPP.')
h('VII. Conclusiones')
p('Se implementó el circuito solicitado con Arduino Uno, HC-05 y dos LED, configurando el enlace UART a 9600 baudios. El programa recibió los cuatro comandos de control, confirmó su recepción y conservó las salidas frente a una orden inválida. Las 50 pruebas principales y la verificación adicional de V cumplieron los estados previstos en el entorno simulado.')
p('La práctica permitió relacionar Bluetooth, comunicación serial y control de salidas con un ejemplo sencillo. La conservación del código, el proyecto, las capturas y los registros completos hace posible revisar el procedimiento. El montaje es una base para una prueba física posterior, cuyo comportamiento inalámbrico deberá medirse por separado.')
h('VIII. Archivos y reproducción')
urls=json.loads((BASE/'ENLACES.json').read_text(encoding='utf-8')) if (BASE/'ENLACES.json').exists() else {}
p('El proyecto portable se abre en Mokxi desde Save → Open JSON or SPICE…, seleccionando Entrega2.mokxi.json. Después se presiona Run, se abre Bluetooth y se envía B, R, A, X o 0, esperando la respuesta entre órdenes. El archivo .ino contiene el código completo; el ZIP conserva la estructura de carpetas, los scripts y las evidencias.')
for label,key in [('Repositorio público','github'),('Circuito en el simulador','simulador')]:
    a=p(label+': ');a.paragraph_format.first_line_indent=Mm(0)
    a.alignment=WD_ALIGN_PARAGRAPH.LEFT
    url=urls.get(key)
    if url:
        link=OxmlElement('w:hyperlink');link.set(qn('r:id'),doc.part.relate_to(url,RT.HYPERLINK,is_external=True))
        run=OxmlElement('w:r');text=OxmlElement('w:t');text.text=url;run.append(text);link.append(run);a._p.append(link)
    else:a.add_run('Pendiente de publicación y verificación.')
h('Referencias')
refs=[
'[1] Politécnico Grancolombiano, “Uso práctico de Arduino”, guía de la asignatura Internet de las Cosas, Entrega previa 2, p. 5, s. f.',
'[2] J. A. Figueroa Guerrero, “Sesión sincrónica de Internet de las Cosas”, orientaciones del Escenario 5, transcripción de clase facilitada por el estudiante, s. f.',
'[3] Arduino, “UNO Rev3”, documentación de hardware. [En línea]. Disponible: https://docs.arduino.cc/hardware/uno-rev3/. Consulta: 21 nov. 2026.',
'[4] Bluetooth SIG, “Serial Port Profile 1.2”. [En línea]. Disponible: https://www.bluetooth.com/specifications/specs/serial-port-profile-1-2/. Consulta: 21 nov. 2026.',
'[5] ITead Studio, “HC-05 Bluetooth to Serial Port Module”, ficha técnica, 18 jun. 2010. [En línea]. Disponible: https://cdn-reichelt.de/documents/datenblatt/A300/ARDUINO_HC-05-4_ISTD016A.pdf.',
'[6] Arduino, “SoftwareSerial Library”, bibliotecas integradas. [En línea]. Disponible: https://docs.arduino.cc/learn/built-in-libraries/software-serial/. Consulta: 21 nov. 2026.',
'[7] G. Koulouras, S. Katsoulis y F. Zantalis, “Evolution of Bluetooth Technology: BLE in the IoT Ecosystem”, Sensors, vol. 25, no. 4, art. 996, 2025, doi: 10.3390/s25040996.',
'[8] S. A. Basha et al., “Advanced Voice and Text Assistant Home Automation System Using Arduino”, en Proceedings of ICCSCE 2025, pp. 2523–2537, 2025, doi: 10.2991/978-94-6463-858-5_210.',
'[9] R. Abburi, M. Praveena y R. Priyakanth, “TinkerCad - A Web Based Application for Virtual Labs to help Learners Think, Create and Make”, Journal of Engineering Education Transformations, vol. 34, ed. esp., pp. 535–541, 2021, doi: 10.16920/jeet/2021/v34i0/157209.',
'[10] Mokxi, “Bluetooth, simulated”, documentación del editor. [En línea]. Disponible: https://mokxi.com/docs/editor/bluetooth. Consulta: 21 nov. 2026.'
]
# IEEE numera las fuentes segun su primera aparicion en el articulo.
order={1:1,2:2,3:3,6:4,7:5,5:6,4:7,8:8,9:9,10:10}
def remap_citation(match):return '['+str(order[int(match.group(1))])+']'
for node in doc._element.iter(qn('w:t')):
    if node.text:node.text=re.sub(r'\[(\d+)\]',remap_citation,node.text)
refs=[re.sub(r'\[(\d+)\]',remap_citation,ref) for ref in refs]
refs.sort(key=lambda ref:int(re.match(r'\[(\d+)\]',ref).group(1)))
for ref in refs:
    a=p(ref);a.paragraph_format.first_line_indent=Mm(-3);a.paragraph_format.left_indent=Mm(3)
    for run in a.runs:run.font.size=Pt(8)
doc.core_properties.title='Control de dos luces LED mediante Arduino y Bluetooth en simulación'
doc.core_properties.author='Johan Sebastian Soto Ramirez'
doc.core_properties.subject='Internet de las Cosas Entrega 2'
doc.core_properties.comments=''
# Un salto continuo equilibra las dos columnas de la ultima pagina.
last=doc.add_section(WD_SECTION_START.CONTINUOUS)
last._sectPr.find(qn('w:cols')).set(qn('w:num'),'1')
output=I/'Entrega 2 IEEE.docx'
doc.save(output)
# Se conservan byte por byte las cabeceras/pies de la plantilla original.
patched=I/'Articulo_temporal.docx'
with ZipFile(TEMPLATE) as source, ZipFile(output) as generated, ZipFile(patched,'w') as target:
    for item in generated.infolist():
        preserve=(item.filename.startswith('word/header') or item.filename.startswith('word/footer')) and item.filename in source.namelist()
        target.writestr(item,source.read(item.filename) if preserve else generated.read(item.filename))
patched.replace(output)
verification={'pruebas_principales':50,'cumplieron':50,'por_comando':{c:10 for c in expected},'alias_V_verificado':True,'codigo_exportado_identico':True,'capturas_pruebas':50,'origen':'Simulacion real en interfaz web de Mokxi; no radio fisica'}
(R/'verificacion.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2),encoding='utf-8')
(BASE/'FUENTES.md').write_text('# Fuentes del artículo\n\n'+'\n\n'.join(refs)+'\n',encoding='utf-8')
print(json.dumps(verification,ensure_ascii=False));print('Articulo, anexo y graficas generados.')
