"""Construye el proyecto portable de Mokxi a partir del .ino entregado."""
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
parts = [
    dict(id='uno1', type='uno', props={}, x=-660, y=0, rot=0),
    dict(id='bb1', type='breadboard-half', props={}, x=0, y=0, rot=0),
    dict(id='bt1', type='hc05', props={}, x=200, y=-340, rot=0),
    dict(id='rv', type='resistor', props={'value': 220}, x=40, y=40, rot=0),
    dict(id='rr', type='resistor', props={'value': 220}, x=340, y=40, rot=0),
    dict(id='verde', type='led', props={'color': 'green'}, x=160, y=20, rot=0),
    dict(id='rojo', type='led', props={'color': 'red'}, x=460, y=20, rot=0),
    dict(id='r_tx', type='resistor', props={'value': 1000}, x=-40, y=-240, rot=0),
    dict(id='r_gnd', type='resistor', props={'value': 2000}, x=60, y=-160, rot=0),
]
wires = []
def wire(a, b, color, bends=()):
    wires.append(dict(id='w'+str(len(wires)+1), **{'from':a, 'to':b}, color=color,
                      bends=[dict(x=x,y=y) for x,y in bends]))
wire('uno1:5V','bb1:tp3','#e14b4b',[(-500,480),(80,480)])
wire('uno1:GNDb','bb1:tn5','#263344',[(-480,520),(120,520)])
wire('bt1:VCC','bb1:tp10','#e14b4b',[(260,-80),(240,-80)])
wire('bt1:GND','bb1:tn13','#263344',[(280,-60),(320,-60)])
wire('bt1:TXD','uno1:2','#20b2c6',[(300,-140),(-240,-140)])
wire('uno1:3','r_tx:1','#e8a33d',[(-260,-220),(-40,-220)])
wire('r_tx:2','bt1:RXD','#e8a33d',[(180,-220),(320,-220)])
wire('r_tx:2','r_gnd:1','#e8a33d',[(40,-140)])
wire('r_gnd:2','bb1:tn17','#263344',[(140,-40),(400,-40)])
wire('uno1:8','rv:1','#26823f',[(-380,-100),(40,-100)])
wire('rv:2','verde:A','#26823f')
wire('verde:C','bb1:tn20','#263344',[(200,160),(460,160)])
wire('uno1:9','rr:1','#d1333f',[(-400,-120),(340,-120)])
wire('rr:2','rojo:A','#d1333f')
wire('rojo:C','bb1:tn23','#263344',[(500,180),(520,180)])
code=(BASE/'codigo/ControlBluetooth/ControlBluetooth.ino').read_text(encoding='utf-8')
project=dict(version=1,name='Entrega 2 - Control Bluetooth de dos LED',parts=parts,wires=wires,
             projects={'uno1':{'files':{'sketch.ino':code}}})
(BASE/'simulacion').mkdir(exist_ok=True)
(BASE/'simulacion/Entrega2.mokxi.json').write_text(json.dumps(project,ensure_ascii=False,indent=2),encoding='utf-8')
print('Proyecto portable creado:',len(parts),'componentes;',len(wires),'conexiones.')
