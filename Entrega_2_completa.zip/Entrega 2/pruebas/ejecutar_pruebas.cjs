// Pruebas reales de la interfaz web. Requiere Node.js, Playwright y Chrome.
// Instalar Playwright: npm install playwright
const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const {chromium}=require('playwright');
const BASE=path.resolve(__dirname,'..');
const OUT=path.join(BASE,'resultados');
const CAP=path.join(OUT,'capturas');
fs.mkdirSync(CAP,{recursive:true});
(async()=>{
 const browser=await chromium.launch({channel:'chrome',headless:true});
 const page=await browser.newPage({viewport:{width:1700,height:1200}});
 try{
  await page.goto('https://mokxi.com/app/?project=bluetooth-chat',{waitUntil:'domcontentloaded'});
  await page.getByRole('textbox',{name:'Code',exact:true}).waitFor();
  await page.waitForTimeout(2200); // Carga asincrona del ejemplo inicial
  await page.getByRole('button',{name:'Save menu',exact:true}).click();
  const chooser=page.waitForEvent('filechooser');
  await page.getByText('Open JSON or SPICE…',{exact:true}).click();
  await (await chooser).setFiles(path.join(BASE,'simulacion/Entrega2.mokxi.json'));
  await page.getByRole('button',{name:'OK',exact:true}).click({timeout:1000}).catch(()=>{});
  const divider=await page.getByRole('separator',{name:'Resize the bottom panel'}).boundingBox();
  await page.mouse.move(divider.x+divider.width/2,divider.y+divider.height/2);
  await page.mouse.down(); await page.mouse.move(divider.x+divider.width/2,800,{steps:10}); await page.mouse.up();
  await page.getByRole('button',{name:'Center the circuit',exact:true}).click();
  await page.screenshot({path:path.join(CAP,'00_diseno_y_codigo.png')});
  await page.getByRole('button',{name:'Run',exact:true}).click();
  await page.getByRole('button',{name:'Stop',exact:true}).waitFor({timeout:30000});
  await page.locator('.serial-line').filter({hasText:'id,tiempo_ms,comando'}).waitFor({timeout:10000});
  const rows=[];
  for(let ciclo=1;ciclo<=10;ciclo++){
   // X se envia despues de A: debe conservar AMBOS LED encendidos.
   for(const comando of ['B','R','A','X','0']){
    const id=rows.length+1;
    await page.getByRole('button',{name:'Bluetooth',exact:true}).click();
    const input=page.getByRole('textbox',{name:'Send over Bluetooth',exact:true});
    await input.waitFor();
    await input.fill(comando); await input.press('Enter');
    await page.getByRole('button',{name:'Back',exact:true}).click();
    const line=page.locator('.serial-line').filter({hasText:new RegExp('^uno1\\s*›\\s*'+id+',[0-9]+,'+comando+',')});
    await line.waitFor({timeout:10000});
    const record=(await line.innerText()).replace(/^uno1\s*›\s*/,'').trim();
    const values=record.split(',');
    const expected=({B:['1','0','OK'],R:['0','1','OK'],A:['1','1','OK'],X:['1','1','INVALIDO'],'0':['0','0','OK']})[comando];
    assert.equal(Number(values[0]),id);
    assert.deepEqual(values.slice(3),expected);
    const captura=String(id).padStart(2,'0')+'_'+comando+'_repeticion_'+ciclo+'.png';
    await page.screenshot({path:path.join(CAP,captura)});
    rows.push({id:Number(values[0]),tiempo_ms:Number(values[1]),comando:values[2],
       verde:Number(values[3]),rojo:Number(values[4]),resultado:values[5],
       repeticion:ciclo,verificacion:'CUMPLE',captura:'capturas/'+captura,
       fecha_utc:new Date().toISOString()});
    console.log(record+' | CUMPLE');
   }
  }
  fs.writeFileSync(path.join(OUT,'monitor_serial_50_original.txt'),await page.locator('#serial-pane').innerText(),'utf8');
  fs.writeFileSync(path.join(OUT,'pruebas_50.json'),JSON.stringify(rows,null,2),'utf8');
  const fields=Object.keys(rows[0]);
  fs.writeFileSync(path.join(OUT,'pruebas_50.csv'),'\uFEFF'+fields.join(',')+'\n'+rows.map(r=>fields.map(f=>r[f]).join(',')).join('\n')+'\n','utf8');
  // Comprobacion adicional del alias V; no se cuenta dentro de las 50.
  await page.getByRole('button',{name:'Bluetooth',exact:true}).click();
  await page.getByRole('textbox',{name:'Send over Bluetooth',exact:true}).fill('V');
  await page.getByRole('textbox',{name:'Send over Bluetooth',exact:true}).press('Enter');
  await page.getByRole('button',{name:'Back',exact:true}).click();
  await page.locator('.serial-line').filter({hasText:/uno1.*51,[0-9]+,V,1,0,OK/}).waitFor();
  await page.screenshot({path:path.join(CAP,'51_alias_V.png')});
  fs.writeFileSync(path.join(OUT,'monitor_serial_con_alias_original.txt'),await page.locator('#serial-pane').innerText(),'utf8');
  await page.getByRole('button',{name:'Bluetooth',exact:true}).click();
  await page.getByRole('textbox',{name:'Send over Bluetooth',exact:true}).waitFor();
  await page.screenshot({path:path.join(CAP,'52_terminal_bluetooth.png')});
  const download=page.waitForEvent('download');
  await page.getByRole('button',{name:'Save menu',exact:true}).click();
  await page.getByText('Download JSON',{exact:true}).click();
  await (await download).saveAs(path.join(BASE,'simulacion/Exportacion_editor.mokxi.json'));
  fs.writeFileSync(path.join(OUT,'entorno.json'),JSON.stringify({simulador:'Mokxi',url:page.url(),
   motor:await browser.version(),inicio_registros:rows[0].fecha_utc,fin_registros:rows.at(-1).fecha_utc,
   medio:'Panel Bluetooth -> HC-05 modelado -> UART -> SoftwareSerial -> LED',
   limite:'Sin radiofrecuencia, telefono fisico ni medicion de alcance'},null,2),'utf8');
  console.log('COMPLETADO: 50 pruebas principales y 1 prueba del alias V.');
 }catch(error){
  await page.screenshot({path:path.join(OUT,'error_ejecucion.png')}).catch(()=>{});
  throw error;
 }finally{await browser.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
