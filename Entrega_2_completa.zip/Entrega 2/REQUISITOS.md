# Revisión de requisitos de la Entrega 2

La guía y la transcripción son las fuentes de requisitos de la actividad.
Se aplicó la petición del estudiante de desarrollar la Entrega 2 con el alcance de esas fuentes y las mejoras pertinentes de la evaluación anterior.

| Requisito | Fuente | Evidencia |
| --- | --- | --- |
| Diseñar, implementar y configurar Arduino con Bluetooth | Guía original, p. 5, Entrega previa 2 | Archivo nativo del simulador y Fig. 1. |
| Configurar enlace serial | Guía, p. 5; transcripción, configuración serial | HC-05/SoftwareSerial a 9600 baudios, 8N1; artículo III y IV. |
| Simular y probar | Guía, p. 5 | 50 registros, 50 capturas, anexo PDF. |
| Dos LED, verde y rojo, resistencias y protoboard | Imagen de la guía; explicación del circuito en clase | Circuito de nueve componentes, incluyendo divisor de tensión. |
| Investigar Bluetooth, HC-05, UART, RX/TX, baudios e IoT | Transcripción completa, explicación previa al montaje | Artículo II; referencias oficiales y tres publicaciones científicas. |
| Código C/C++ comentado | Transcripción, explicación de implementación | ControlBluetooth.ino completo. |
| Inicializar serial, salidas, interpretar comandos y mostrar monitor | Transcripción, explicación de código | setup(), procesarComando(), loop() y monitor original. |
| Rechazar comandos incorrectos | Transcripción, validación de comandos | Diez X después de A; ambos LED conservan el estado activo. |
| B, R, A y 0 | Transcripción, lista de comandos y demostración | Diez pruebas por comando; V como alias adicional. |
| Cinco pruebas por comando | Transcripción completa, frase «deben hacer cinco pruebas con cada uno de los comandos» | Diez por cada uno de los cinco casos; 50 en total. |
| Capturas de circuito, código, ejecución, monitor y cada prueba | Transcripción, explicación inmediatamente posterior a las pruebas | Captura 00, pruebas 01 a 50, alias 51 y terminal 52. |
| Artículo IEEE con título, autor, resumen, Abstract, palabras clave, introducción, objetivos, marco, metodología, implementación, resultados, discusión, límites, conclusiones y referencias | Transcripción, enumeración de secciones | Artículo en Word y PDF. Se añadieron Index Terms por la observación anterior. |
| Adjuntar código, enlace público del simulador y evidencias | Transcripción, enumeración de entregables; retroalimentación anterior | .ino, ENLACES.json, README, capturas y registros originales. |
| Repositorio GitHub | Transcripción lo condiciona a usar GitHub; retroalimentación pide incorporarlo en futuras entregas | Repositorio público con código y proyecto completo. |
| Modalidad individual | Decisión del estudiante en este chat | Nota de presentación para Canvas; no se inventa una autorización adicional. |

La guía ubica el circuito Wi-Fi en la entrega final, p. 6. No se añadió Wi-Fi a la Entrega 2.
La medición de CPU/RAM pertenece a la actividad anterior: la transcripción nueva no la establece como prueba del circuito Bluetooth.
La mención a memoria de microcontroladores en clase es conceptual, no una instrucción de medir el sistema operativo.
No se inventaron capturas de intentos de contacto ni se atribuyó a Johan el permiso individual dirigido a otra estudiante.
